from math import sqrt


def geron(a,b,c):
    p=a+b+c
    return sqrt(p*(p-a)*(p-b)*(p-c))
