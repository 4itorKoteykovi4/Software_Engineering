import time
from datetime import datetime

for i in range(0,5):
    now = datetime.now()
    print("{}:{}:{}".format(now.hour, now.minute, now.second))
    time.sleep(1)
