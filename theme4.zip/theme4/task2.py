import random


def gg():
    t = random.randint(1, 6)
    print(f'Выпало: {t}')
    if t in range(3, 5):
        t = gg()
    return t


if __name__ == '__main__':
    print('Вы победили' if gg() in range(1, 3) else 'Вы проиграли')
