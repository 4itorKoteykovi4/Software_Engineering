def main(*args):
    count = 0
    sums = 0
    for i in args:
        sums += i
        count += 1
    print(sums/count)


if __name__ == '__main__':
    main(1, 2, 3, 4, 5, 6, 7, 8, 9)
