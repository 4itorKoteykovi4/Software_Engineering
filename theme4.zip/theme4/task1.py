#Подключаем объект datetime из библиотеки datetime
from datetime import datetime
#Подключаем объект sqrt из библиотеки math
from math import sqrt

def main(**kwargs):
    """
    Функция для вычисления

    Args:
        **kwargs (Any): Набор данных

    Returns:
        void
    """
    #Проходим по всем полученным аргументам
    for key in kwargs.items():
        #Вычисления
        result = sqrt(key[1][0] ** 2 + key[1][1] ** 2)
        #Вывод результата
        print(result)

#Точка входа
if __name__ == '__main__':
    #Время начала выполнения программы
    start_time = datetime.now()
    #Вычисления
    main(
        опе=[10, 3],
        two=[5, 4],
        three=[15, 13],
        four=[93, 53],
        five=[133, 15]
    )
    #Время выполнения программы
    time_costs = datetime.now() - start_time
    #Вывод времени выполнения программы
    print(f"Время выполнения программы - {time_costs}")
