from geron import geron

if __name__ == '__main__':
    a = int(input("Введите длину первой стороны: "))
    b = int(input("Введите длину первой стороны: "))
    c = int(input("Введите длину первой стороны: "))
    print(f'Площадь треугольника: {geron(a, b, c)}')
