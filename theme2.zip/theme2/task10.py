def is_palindrome(text):
    text = text.lower().replace(' ', '')
    if text == text[::-1]:
        return True
    else:
        return False


text = input('Введите текст: ')
if is_palindrome(text):
    print('Палиндром')
else:
    print('Палиндром')