day, month, year = 2, 'Января', 2001
print(f'Сегодня {day} {month} {year}.', end=' Всего хорошего!')
