a, b, c = 5, 3, 9
print(f'{a}, {b}, {c}')