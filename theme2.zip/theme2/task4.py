a = '11111'
print(a+a+a+a+a+a)