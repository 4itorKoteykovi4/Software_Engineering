s = 'Hello World'
print(s.replace(' ', ' my '))
