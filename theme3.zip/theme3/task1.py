x=1

for i in range(2):
    x*=5
    x+=1

print(x)