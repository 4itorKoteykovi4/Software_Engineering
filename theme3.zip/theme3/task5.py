memory = ' world'
counter = 0
values = [0,2,4,6,8,10]

while counter != 10:
    string = 'hello'
    if counter in values:
        string = string + ' world'
    counter += 1
    print(string)

while ' world' not in string:
    print(string + memory)
    string = ' world'




