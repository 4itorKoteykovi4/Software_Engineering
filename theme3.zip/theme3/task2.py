for i in reversed("Hello world"):
    print(i)
