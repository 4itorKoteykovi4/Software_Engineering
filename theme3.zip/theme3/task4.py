sentence = input("Введите предложение: ")
print("Длина:", len(sentence))
sentence=sentence.lower()
print("Нижний регистр:", sentence)

print("Количество ""a"":", sentence.count('a'))
print("Количество ""e"":", sentence.count('e'))
print("Количество ""i"":", sentence.count('i'))
print("Количество ""o"":", sentence.count('o'))
print("Количество ""u"":", sentence.count('u'))

sentence = sentence.replace("ugly", "beauty")
print("После замены:", sentence)

print("Начинается ли с ""the"" и заканчивается ли на ""end"":", "True" if (sentence.startswith("the") and sentence.endswith("end")) else "False")